import os

BASE_URL = os.getenv('BASE_URL', 'https://dummy-ai-api.onrender.com')
API_TIMEOUT = 2
